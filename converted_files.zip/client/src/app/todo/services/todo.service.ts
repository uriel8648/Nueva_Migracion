import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { environment } from '../../../../environments/environment';
import { Todo } from '../models/todo.model';

/**
 * TodoService - Handles all CRUD operations for Todo items
 * 
 * This service replaces the $http calls from the original AngularJS TodoController.
 * It uses Angular's HttpClient with RxJS Observables instead of promises.
 * Error handling is centralized using RxJS operators.
 */
@Injectable({
  providedIn: 'root' // Makes the service tree-shakable and available application-wide
})
export class TodoService {
  // API URL from environment configuration
  private readonly apiUrl = environment.apiUrl || 'api';
  private readonly todosUrl = `${this.apiUrl}/todos`;

  constructor(private http: HttpClient) { }

  /**
   * Fetches all todos from the API
   * Migrated from $scope.loadTodos
   */
  getAllTodos(): Observable<Todo[]> {
    return this.http.get<Todo[]>(this.todosUrl).pipe(
      catchError(error => this.handleError(error))
    );
  }

  /**
   * Creates a new todo
   * Migrated from $scope.createTodo
   */
  createTodo(todo: Todo): Observable<Todo> {
    return this.http.post<Todo>(this.todosUrl, todo).pipe(
      catchError(error => this.handleError(error))
    );
  }

  /**
   * Updates an existing todo
   * Migrated from $scope.updateTodo
   */
  updateTodo(todo: Todo): Observable<Todo> {
    return this.http.put<Todo>(`${this.todosUrl}/${todo.id}`, todo).pipe(
      catchError(error => this.handleError(error))
    );
  }

  /**
   * Deletes a todo by ID
   * Migrated from $scope.deleteTodo
   */
  deleteTodo(id: number): Observable<void> {
    return this.http.delete<void>(`${this.todosUrl}/${id}`).pipe(
      catchError(error => this.handleError(error))
    );
  }

  /**
   * Toggles the completed status of a todo
   * Migrated from $scope.toggleStatus
   */
  toggleTodoStatus(id: number): Observable<Todo> {
    return this.http.put<Todo>(`${this.todosUrl}/${id}/toggle`, {}).pipe(
      catchError(error => this.handleError(error))
    );
  }

  /**
   * Centralized error handler for HTTP requests
   * Converts HttpErrorResponse to an Observable that errors
   */
  private handleError(error: HttpErrorResponse): Observable<never> {
    let errorMessage = 'An unknown error occurred';
    
    if (error.error instanceof ErrorEvent) {
      // Client-side error
      errorMessage = `Error: ${error.error.message}`;
    } else {
      // Server-side error
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    
    // Log the error to console (equivalent to original console.error)
    console.error(errorMessage, error);
    
    // Return an observable with a user-facing error message
    return throwError(() => new Error(errorMessage));
  }
}