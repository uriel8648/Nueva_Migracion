/**
 * Todo model interface for the Angular application
 * 
 * This is a TypeScript interface representation of the Java Todo model.
 * It defines the structure and types for Todo objects used throughout the application.
 * 
 * The interface is kept simple and focused on data structure without business logic,
 * following Angular best practices for model definitions.
 */
export interface Todo {
  id?: number;
  title: string;
  description: string;
  completed: boolean;
  createdDate: Date;
  completedDate?: Date;
}

/**
 * Factory function to create a new Todo with default values
 * 
 * This replaces the Java constructor functionality by providing
 * a convenient way to create new Todo objects with initialized values.
 * Uses TypeScript's Partial type for flexible parameter passing.
 */
export function createTodo(params: Partial<Todo> = {}): Todo {
  return {
    title: params.title || '',
    description: params.description || '',
    completed: params.completed || false,
    createdDate: params.createdDate || new Date(),
    completedDate: params.completedDate || undefined,
    id: params.id
  };
}

/**
 * Helper function to mark a Todo as completed
 * 
 * This implements the same logic as the Java setCompleted method,
 * setting the completedDate when a todo is marked as completed
 * and clearing it when marked incomplete.
 * 
 * Uses the immutable pattern with object spread operator for state updates.
 */
export function setTodoCompleted(todo: Todo, completed: boolean): Todo {
  return {
    ...todo,
    completed,
    completedDate: completed ? new Date() : undefined
  };
}

/**
 * Helper function to convert a Todo to string representation
 * 
 * Mimics the Java toString() method for debugging purposes
 */
export function todoToString(todo: Todo): string {
  return `Todo [id=${todo.id}, title=${todo.title}, completed=${todo.completed}]`;
}