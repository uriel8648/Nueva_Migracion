import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable, throwError, Subject } from 'rxjs';
import { catchError, map, switchMap, tap, takeUntil } from 'rxjs/operators';
import { Todo } from '../../models/todo.model';
import { TodoService } from '../../services/todo.service';

/**
 * Component responsible for displaying the details of a specific todo item.
 * Allows viewing, toggling status, editing, and deleting the todo.
 */
@Component({
  selector: 'app-todo-detail',
  templateUrl: './todo-detail.component.html',
  styleUrls: ['./todo-detail.component.scss']
})
export class TodoDetailComponent implements OnInit, OnDestroy {
  todo: Todo | null = null;
  todoId: number | null = null;
  loading = true;
  error = false;
  errorMessage = '';
  
  // Subject for handling unsubscription on component destroy
  private destroy$ = new Subject<void>();

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private todoService: TodoService
  ) { }

  ngOnInit(): void {
    this.loadTodoDetails();
  }

  ngOnDestroy(): void {
    // Clean up subscriptions when component is destroyed
    this.destroy$.next();
    this.destroy$.complete();
  }

  /**
   * Loads the todo details from the route parameter ID
   */
  private loadTodoDetails(): void {
    this.route.paramMap.pipe(
      map(params => {
        const id = params.get('id');
        return id ? parseInt(id, 10) : null;
      }),
      tap(id => {
        this.todoId = id;
        this.loading = true;
        this.error = false;
      }),
      switchMap(id => {
        if (id === null) {
          return throwError(() => new Error('Todo ID is required'));
        }
        return this.todoService.getTodoById(id);
      }),
      catchError(err => {
        console.error('Error loading todo details:', err);
        this.error = true;
        this.loading = false;
        this.errorMessage = 'Failed to load todo details. Please try again.';
        return throwError(() => err);
      }),
      takeUntil(this.destroy$)
    ).subscribe({
      next: (todo: Todo) => {
        this.todo = todo;
        this.loading = false;
      },
      error: (error) => {
        this.error = true;
        this.loading = false;
        this.errorMessage = 'Failed to load todo details. Please try again.';
      }
    });
  }

  /**
   * Toggle the completed status of the current todo
   */
  toggleStatus(): void {
    if (!this.todo || !this.todoId) {
      return;
    }

    const originalStatus = this.todo.completed;
    this.todo.completed = !this.todo.completed;

    this.todoService.toggleTodoStatus(this.todoId).pipe(
      catchError(error => {
        console.error('Error toggling todo status:', error);
        // Revert the UI change if the API call fails
        if (this.todo) {
          this.todo.completed = originalStatus;
        }
        this.errorMessage = 'Failed to update todo status. Please try again.';
        return throwError(() => error);
      }),
      takeUntil(this.destroy$)
    ).subscribe({
      next: (updatedTodo: Todo) => {
        this.todo = updatedTodo;
      },
      error: (error) => {
        // Error already handled in catchError
      }
    });
  }

  /**
   * Navigate to the edit page for this todo
   */
  editTodo(): void {
    if (this.todoId) {
      this.router.navigate(['/todos', this.todoId, 'edit']);
    }
  }

  /**
   * Delete the current todo and navigate back to the list
   */
  deleteTodo(): void {
    if (!this.todoId) {
      return;
    }

    if (confirm('Are you sure you want to delete this todo?')) {
      this.todoService.deleteTodo(this.todoId).pipe(
        catchError(error => {
          console.error('Error deleting todo:', error);
          this.errorMessage = 'Failed to delete todo. Please try again.';
          return throwError(() => error);
        }),
        takeUntil(this.destroy$)
      ).subscribe({
        next: () => {
          this.router.navigate(['/todos']);
        },
        error: (error) => {
          // Error already handled in catchError
        }
      });
    }
  }

  /**
   * Navigate back to the todo list
   */
  goBack(): void {
    this.router.navigate(['/todos']);
  }
}